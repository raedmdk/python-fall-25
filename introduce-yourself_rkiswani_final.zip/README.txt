Introduce Yourself — rkiswani

How to publish:
1) Upload the entire 'introduce-yourself' folder to cPanel under public_html/
2) Your live link will be: http://rkiswani.mccweb.net/introduce-yourself/index.html
3) Push the same folder to a public GitHub repo and submit both links in Canvas.

Photos:
All images are your real photos placed in /images with exact names used by the HTML.
