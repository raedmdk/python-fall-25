def add(a, b):
    return a + b


x = 5
y = 7
print("sum:", add(x, y))
