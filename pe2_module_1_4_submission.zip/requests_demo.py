# Extra credit example: simple requests usage
# NOTE: This requires 'requests' installed via: pip install requests
import requests

def main():
    r = requests.get("https://example.com")
    print("Status code:", r.status_code)
    print("First 60 chars of page:", r.text[:60])

if __name__ == "__main__":
    main()
