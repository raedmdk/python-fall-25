PE2 Module 1.4 – PIP & AutoPEP8 (Submission Pack)

What to submit (base assignment):
  • A screenshot of VS Code showing that AutoPEP8 formatted a Python file.
    - Use 'format_me_before.py' in VS Code.
    - Run: Ctrl/Cmd+Shift+P → "Format Document With" → autopep8.
    - It should match 'format_me_after.py' (for your reference).

How to take the screenshot:
  • Windows: Win + Shift + S → select the VS Code window.
  • Mac: Cmd + Shift + 4 → select the VS Code window.

Extra Credit (home computer only, with pip):
  1) Verify installs:
     - python --version
     - pip --version  (or: python -m pip --version)
  2) Install the package:
     - pip install requests
  3) Run the demo:
     - python requests_demo.py
  4) Submit:
     - Screenshot 1: pip install success
     - Screenshot 2: terminal running requests_demo.py (output visible)
     - Include the 'requests_demo.py' file

Quick pip cheat sheet:
  - pip install PACKAGE
  - pip install --upgrade PACKAGE
  - pip uninstall PACKAGE
  - pip list
  - pip show PACKAGE
  - pip install PACKAGE==1.2.3

Tip: If pip is confusing on your system, use:
  python -m pip install PACKAGE

Files included in this ZIP:
  - format_me_before.py    (intentionally messy — use this in VS Code and format with autopep8)
  - format_me_after.py     (what the formatted result should look like)
  - requests_demo.py       (extra credit example that uses 'requests')
  - Reflection.txt         (short write-up you can submit)
  - AI_Statement.txt       (disclosure of AI assistance)

Submission checklist:
  [ ] Uploaded screenshot of formatted code (AutoPEP8) to Canvas
  [ ] (Extra credit) Two screenshots + requests_demo.py
  [ ] Mentioned AI tool used in comments or attached AI_Statement.txt
