Submission Instructions (PE2 Module 1.3 – Packages)

Folder layout:
pe2_packages_project/
├─ main.py
└─ math_operations/
   ├─ __init__.py
   ├─ calculator.py
   └─ geometry.py

How to run:
1) Open a terminal in the pe2_packages_project folder.
2) Run: python main.py

Canvas Submission:
- Upload the 'pe2_packages_submission.zip' file OR upload the whole folder contents.
- In comments, paste a short reflection and mention you used ChatGPT for help.

GitHub Submission:
1) Create a new repository named pe2_packages_project.
2) Upload the folder contents (main.py and the math_operations folder).
3) Add Reflection.txt and AI_Statement.txt to the repo.
4) Copy the repo URL and submit it in Canvas.
