# PE2 Module 1.3 - Modules and Packages
# Author: Raed Al Kiswani
# Date: October 7, 2025

from math_operations import calculator
from math_operations import geometry

def main():
    print("=== Calculator Functions ===")
    print("7 + 2 =", calculator.add(7, 2))
    print("10 - 4 =", calculator.subtract(10, 4))

    print("\n=== Geometry Functions ===")
    print("Area of square (side=4):", geometry.area_square(4))
    print("Area of rectangle (3x5):", geometry.area_rectangle(3, 5))
    print("Area of circle (radius=5):", geometry.area_circle(5))

main()
