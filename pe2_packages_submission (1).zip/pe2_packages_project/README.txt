PE2 Module 1.3 – Modules and Packages

How to run:
  1) Open a terminal in this folder (pe2_packages_project).
  2) Run:  python main.py

Expected output:
  === Calculator Functions ===
  7 + 2 = 9
  10 - 4 = 6

  === Geometry Functions ===
  Area of square (side=4): 16
  Area of rectangle (3x5): 15
  Area of circle (radius=5): 78.5

Notes:
- math_operations is a package because it contains __init__.py
- calculator.py and geometry.py are modules imported in main.py
- Only basics used: def, return, import, print
