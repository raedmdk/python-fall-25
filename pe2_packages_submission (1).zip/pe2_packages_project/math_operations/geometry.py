def area_square(side):
    return side * side

def area_rectangle(width, height):
    return width * height

def area_circle(radius):
    pi = 3.14
    return pi * radius * radius
