# PE2 Modules 1.1 & 1.2 – Number Guessing Game
# Author: Raed Al Kiswani
# Date: October 7, 2025
#
# Uses: import random, while loop, abs(), main() function.
# Goal: Guess a random number between 1 and 100 with proximity feedback.

import random

def feedback_from_diff(diff):
    if diff <= 5:
        return "Very Hot"
    elif diff <= 15:
        return "Hot"
    elif diff <= 25:
        return "Cool"
    else:
        return "Cold"

def main():
    print("Welcome to Raed's Guessing Game (1 to 100)")
    secret = random.randint(1, 100)
    guess = None

    while guess != secret:
        raw = input("Enter your guess (1–100): ")
        if not raw.isdigit():
            print("Please enter digits only.")
            continue

        guess = int(raw)
        if guess < 1 or guess > 100:
            print("Keep it between 1 and 100.")
            guess = None
            continue

        diff = abs(guess - secret)
        if guess == secret:
            print("Correct! You got it!")
        else:
            print(feedback_from_diff(diff))

    print("Game over. Thanks for playing!")

if __name__ == "__main__":
    main()
