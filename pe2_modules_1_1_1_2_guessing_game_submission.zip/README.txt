PE2 Modules 1.1 & 1.2 – Number Guessing Game

How to run:
  1) Open a terminal in this folder.
  2) Run:  python guessing_game.py

What this shows:
  - import random
  - while loop for repeated guesses
  - abs() to compute distance from the secret number
  - main() function as program entry point

Expected behavior:
  - Program chooses a secret number from 1 to 100.
  - You guess until you are correct.
  - Feedback categories: Very Hot (<=5), Hot (<=15), Cool (<=25), Cold (>25).
