"""
Final Project – Coffee Shop Ordering System
File: menu_item.py
Author: Raed Al Kiswani
Course: ADD-100 Programming Logic
Description:
    Defines the MenuItem class used to represent one drink or food item
    in the coffee shop menu.
"""

class MenuItem:
    """Represents a single menu item in the coffee shop."""

    def __init__(self, name, category, price):
        """
        Create a new MenuItem.

        :param name: item name, for example "Latte"
        :param category: group such as "Coffee", "Tea", "Bakery"
        :param price: price as a float, for example 4.95
        """
        self._name = name
        self._category = category
        self._price = price

    # getters (accessors)
    def get_name(self):
        return self._name

    def get_category(self):
        return self._category

    def get_price(self):
        return self._price

    # setters (mutators)
    def set_name(self, name):
        self._name = name

    def set_category(self, category):
        self._category = category

    def set_price(self, price):
        self._price = price

    def __str__(self):
        """Nice string for printing on a menu."""
        return f"{self._name} ({self._category}) - ${self._price:.2f}"
