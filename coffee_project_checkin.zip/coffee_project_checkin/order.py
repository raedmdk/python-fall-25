"""
Final Project – Coffee Shop Ordering System
File: order.py
Author: Raed Al Kiswani
Course: ADD-100 Programming Logic
Description:
    Defines the Order class, which will hold MenuItem objects
    for one customer order.
"""

from menu_item import MenuItem


class Order:
    """Represents one coffee shop order for a single customer."""

    def __init__(self, customer_name):
        """
        Create a new empty order.

        :param customer_name: the name of the customer placing the order
        """
        self._customer_name = customer_name
        self._items = []  # this will store MenuItem objects later

    # accessors
    def get_customer_name(self):
        return self._customer_name

    def get_items(self):
        return self._items

    # mutators
    def set_customer_name(self, name):
        self._customer_name = name

    def add_item(self, item):
        """Add a MenuItem to this order."""
        if isinstance(item, MenuItem):
            self._items.append(item)

    def get_total(self):
        """Return the total price of the order."""
        total = 0.0
        for item in self._items:
            total += item.get_price()
        return total

    def __str__(self):
        """Simple text summary of the order."""
        return f"Order for {self._customer_name} with {len(self._items)} item(s)."
