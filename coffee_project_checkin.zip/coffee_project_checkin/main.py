"""
    Final Project Check-In – Coffee Shop Ordering System
    File: main.py
    Author: Raed Al Kiswani
    Course: ADD-100 Programming Logic
    Description:
        This file is the starting point for Raed's final project.
        For the check-in, it shows:
        - imports from separate class files (menu_item.py, order.py)
        - function stubs for loading the menu and getting an order
        - simple input from the user
        - writing a short line to an output text file

        The full project will later:
        - read menu items from data/menu.txt
        - let the user build an order
        - calculate totals and save an order summary to a file
    """

    from menu_item import MenuItem
    from order import Order


    def load_menu(filename="data/menu.txt"):
        """
        Load menu items from a text file.

        For the check-in, this function only shows the structure.
        Later, Raed will:
        - open the file
        - split each line on commas
        - create MenuItem objects
        - return a list of those objects
        """
        menu_items = []

        try:
            with open(filename, "r", encoding="utf-8") as menu_file:
                for line in menu_file:
                    # In the final project, Raed will parse each line like:
                    # category, name, price_text = line.strip().split(",")
                    # price = float(price_text)
                    # item = MenuItem(name, category, price)
                    # menu_items.append(item)
                    pass
        except FileNotFoundError:
            print("Menu file not found yet. Raed will create data/menu.txt soon.")

        return menu_items


    def get_user_order(menu_items):
        """
        Ask the user for their name and (later) their order.

        For this check-in:
        - We only ask for the customer's name.
        - In the final project, this function will let the user
          choose drinks and bakery items by number.
        """
        print("=== Raed's Coffee Shop – Project Check-In Demo ===")
        print("You can imagine this running during a late-night Amazon break.
")

        customer_name = input(
            "Enter your name (Raed / Abdulrahman / Mohammed / Ali or anyone else): "
        ).strip().title()

        # create an Order object, even if it is still empty
        order = Order(customer_name)

        # In the final project, Raed will:
        # - show the menu
        # - let the user add MenuItem objects to the order
        # For now we just return the empty order so we can test data flow.
        return order


    def write_order_summary(order, filename="data/output.txt"):
        """
        Append a very simple summary line to an output file.

        This proves that:
        - the classes connect to main.py
        - file writing works in the project folder
        """
        try:
            with open(filename, "a", encoding="utf-8") as out_file:
                out_file.write(
                    f"Customer: {order.get_customer_name()} "
                    f"- items so far: {len(order.get_items())}\n"
                )
        except OSError as error:
            print("There was a problem writing to the output file:", error)


    def main():
        """Connect the pieces together for the check-in."""
        menu_items = load_menu()
        order = get_user_order(menu_items)
        write_order_summary(order)
        print("\nCheck-in complete: classes imported, input read, file write tested.")


    if __name__ == "__main__":
        main()
